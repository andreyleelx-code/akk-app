"""Refresh public editorial metadata. Never discard a working feed on failure."""
from html.parser import HTMLParser
from urllib.request import Request, urlopen
from urllib.parse import urljoin, urlparse
from pathlib import Path
import json, re, hashlib
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
TARGET = (ROOT / 'dist' / 'news.json') if (ROOT / 'dist').is_dir() else ROOT / 'news.json'
SOURCE = 'https://koreilbo.com/news/'

class NewsLinks(HTMLParser):
    def __init__(self):
        super().__init__(); self.href = None; self.parts = []; self.items = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'a':
            href = urljoin(SOURCE, attrs.get('href', ''))
            if urlparse(href).hostname in ('koreilbo.com', 'www.koreilbo.com') and re.search(r'/news/[^/?#]+/?$', urlparse(href).path):
                self.href = href; self.parts = []
    def handle_data(self, data):
        if self.href: self.parts.append(data)
    def handle_endtag(self, tag):
        if tag == 'a' and self.href:
            title = re.sub(r'\s+', ' ', ' '.join(self.parts)).strip()
            if 15 < len(title) < 220 and not any(x[0] == self.href for x in self.items):
                self.items.append((self.href, title))
            self.href = None; self.parts = []

def fetch(url):
    return urlopen(Request(url, headers={'User-Agent': 'AKK-Digital-Public-News/2.0'}), timeout=25).read().decode('utf-8')

def main():
    try:
        page = fetch(SOURCE); parser = NewsLinks(); parser.feed(page)
        items = []
        for index, (url, title) in enumerate(parser.items[:12]):
            try:
                article = fetch(url)
                match = re.search(r'(?:datePublished["\s:]+|datetime=["\x27])([0-9]{4}-[0-9]{2}-[0-9]{2})', article)
                if not match: continue  # Do not manufacture publication dates.
                date = match.group(1)
                items.append({'id': hashlib.sha256(url.encode()).hexdigest()[:12], 'title': title, 'url': url, 'date': date, 'source': 'Корё ильбо', 'category': 'Сообщество', 'art': index % 4})
            except Exception as error:
                print('Article skipped:', type(error).__name__)
        if not items:
            print('No verified items. Existing feed retained.'); return
        payload = {'updatedAt': datetime.now(timezone.utc).isoformat(), 'items': items}
        temp = TARGET.with_suffix('.tmp')
        temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
        temp.replace(TARGET)
        print('Updated', len(items), 'items')
    except Exception as error:
        print('Source unavailable; existing feed retained:', type(error).__name__)

if __name__ == '__main__': main()
